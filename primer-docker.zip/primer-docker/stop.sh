#!/bin/sh

# stop.sh

# stop running container - typing stop.sh is easier than the whole docker command

docker stop chapter2

